let elem = document.querySelector("#elem");
let parent = elem.parentElement;
let grandparent = parent.parentElement;
grandparent.style.color = "red";