let elem = document.querySelector("#elem");
let lastChild = elem.lastElementChild;
lastChild.style.color = "red";