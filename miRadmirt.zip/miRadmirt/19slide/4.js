let elem = document.getElementById("elem");
elem.classList.toggle("www");