var elem = document.getElementById('elem');
elem.style.cssText = 'color: red; font-size: 30px; border: 1px solid black;';

