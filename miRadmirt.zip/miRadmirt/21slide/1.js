let elem = document.querySelector("#elem");
elem.insertAdjacentHTML("beforebegin", "<span>!!!</span>");